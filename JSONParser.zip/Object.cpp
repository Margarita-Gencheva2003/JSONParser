#include "Object.h"
#include <iostream>
#include "DepthParser.h"
Value* factory(sview s);
ObjectValue::ObjectValue(const ObjectValue& other)
{
	copyFrom(other);
}

ObjectValue& ObjectValue::operator=(const ObjectValue& other)
{
	if (this != &other) {
		free();
		copyFrom(other);
	}
	return *this;
}

void ObjectValue::print() const
{
	size_t len = keys.size();
	for (size_t i = 0; i < len; i++) {
		std::cout << "Key:";
		keys[i].print();
		std::cout << "Value:";
		values[i]->print();
		std::cout << std::endl;
	}
}

void ObjectValue::parse(sview s)
{
	size_t len = s.length();
	if (len == 0)
		throw std::runtime_error("some exception at key-value parsing");
	size_t kvPairBegin = 0, kvPairEnd = 0;
	do {
		DepthParser dp;
		for (; kvPairEnd < len; kvPairEnd++) {
			dp.process(s[kvPairEnd]);
			if (s[kvPairEnd] == ',' && dp.level() == 0)
				break;
		}
		parseKeyValuePair(s.substr(kvPairBegin, kvPairEnd));
		kvPairEnd++;
		kvPairBegin = kvPairEnd;
	} while (kvPairEnd < len);
}

Value* ObjectValue::clone() const
{
	return new ObjectValue(*this);
}

ObjectValue::~ObjectValue()
{
	free();
}

void ObjectValue::copyFrom(const ObjectValue& other)
{
	size_t len = other.values.size();
	for (size_t i = 0; i < len; i++) {
		this->values[i] = other.values[i]->clone();
	}
}

void ObjectValue::free()
{
	size_t len = values.size();
	for (size_t i = 0; i < len; i++)
	{
		delete values[i];
	}
}

void ObjectValue::parseKeyValuePair(sview s)
{
	size_t i = 0, j = 0;
	while (s[i] != ':') {
		++i;
	}
	j = i;
	while (s[j] != '"') {
		--j;
	}
	keys.push_back(s.substr(1, j).trim());
	sview valueStr = s.substr(i + 1, s.length() - (i + 1)).trim();// "a": 2
	Value* value = factory(valueStr);
	values.push_back(value);
}
